app_name = "product"


urlpatterns = []
