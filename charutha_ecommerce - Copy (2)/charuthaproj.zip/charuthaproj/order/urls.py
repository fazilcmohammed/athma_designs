app_name = "order"

urlpatterns = []
