app_name = "accounts"

urlpatterns = []
